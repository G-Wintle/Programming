import java.util.Scanner;

class Main {
  public static void main(String[] args) {

    System.out.println("Welcome to the Pig Latin Translator!");
    

    //String word
    
    Scanner sc = new Scanner(System.in);
    String s = "";
    
    
      do {
        System.out.println("Enter a word:");
        s = sc.nextLine();
        s = s.toUpperCase();

        int i;
        
        for (i = 1; i < s.length(); i++) {
        char ch = s.charAt(i);
       
        
         
        if (ch == 'a' || ch == 'A' || ch == 'e' || ch == 'E' || ch == 'i' || ch ==           'I' || ch == 'o' || ch == 'O' || ch == 'u' || ch == 'U') {
        
          String f = s.substring (i) + s.substring(0,i) + "AY";
          System.out.println(f);
          break;
          }
        
          
          
          
      else if (s.charAt(0) == 'a' || s.charAt(0) == 'A' || s.charAt(0) == 'e' ||                 s.charAt(0) == 'E' || s.charAt(0) == 'i' || s.charAt(0) == 'I' ||                     s.charAt(0) == 'o' || s.charAt(0) == 'O' || s.charAt(0) == 'u' ||                   s.charAt(0) == 'U') {
          System.out.println(s + "WAY");
        break;
        }
        }
        
          
        
    }
    while (!s.equals("Q"));
      
    sc.close();

      
    


  }
  
}